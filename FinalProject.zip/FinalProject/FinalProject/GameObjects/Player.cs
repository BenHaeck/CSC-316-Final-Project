﻿using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;


namespace FinalProject {
	public class Player: PhysicsCharacter<EntityInput> {
		
		// the players bounding box
		//public BBox2D box = new BBox2D (Vector2.Zero, Vector2.One * 20);

		// the sprite renderers
		SpriteRenderer spriteRenderer = new SpriteRenderer ();
		SpriteRenderer gunRenderer = new SpriteRenderer ();

		public float facingDirection => gunRenderer.rotation;

		// recovery
		const float RECOV_HEAVY = 0.65f; // the interval between heavy bullet shots
		float recovHeavyCurrent = 0; // how long until the gun can be fired again

		const float ROT_OFFSET = -MathF.PI/2; // this gets added to the gun and tank rotation
		const float SPEED = 56; // the speed the player moves at
		const float SLOW_SPEED = 10;
		const float SLOW_AMOUNT = 0.17f;

		// this tracks the players health (note, readonly only applies to the reference of health man, not the actual data inside)
		//public readonly HealthMan Health;

		Movement movement = new Movement ();
		public Movement MovementHelper => movement;

		HealthMan health = new HealthMan (30);
		public HealthMan Health => health;

		// this stores a template bullet, and all the information required to shoot a bullet
		readonly BulletEmitter emitter;
		//readonly Movement MovementHelper;

		//partical stuff
		static readonly Point particalSize = new Point (16, 16);
		static readonly float particalVelMult = 0.25f;


		public Player () {
			// sets up the sprite renderers
			spriteRenderer.texture = Game1.tankGBase;
			gunRenderer.texture = Game1.tankGGun;
			gunRenderer.originOffset = -Vector2.UnitY*3;

			// sets up the health manager
			emitter = new BulletEmitter (new Bullet(4, new SpriteRenderer () { texture = Game1.bulletTex}, 10), 240, 12);
			//Health = new HealthMan (30);
			var helpers = new object[] { movement, health, emitter };
			SetHelpers (helpers);

			/*for (int i = 0; i < helpers.Length; i++) {
				Debug.WriteLine (helpers[i]);
			}

			MoveObjectToFront (2);
			for (int i = 0; i < helpers.Length; i++) {
				Debug.WriteLine (helpers[i]);
			}*/

			//SetHelperObjects (new Movement (), new HealthMan(30));
			MovementHelper.VelChange = 3;
			box.Size = Vector2.One * 20;
		}

		// gameplay logic
		public override void Update (EntityInput input, float dt) {
			// decreases recovery every frame (and keeps it from going below zero)
			recovHeavyCurrent = MathF.Max (0, recovHeavyCurrent - dt);
			GameWorld gameWorld = input.gameWorld;
			var enemyBullets = input.gameWorld.enemyBullets;
			// gets the direction the player wants to go in
			Vector2 dir = Vector2.Zero;
			// dir.x
			if (Game1.keyboardState.IsKeyDown (Keys.D))
				dir.X += 1;
			if (Game1.keyboardState.IsKeyDown (Keys.A))
				dir.X -= 1;
			// dir.y
			if (Game1.keyboardState.IsKeyDown (Keys.S))
				dir.Y += 1;
			if (Game1.keyboardState.IsKeyDown (Keys.W))
				dir.Y -= 1;

			// handles rotation & direction
			if (dir != Vector2.Zero) {
				dir.Normalize ();
			}
			if (MovementHelper.velocity != Vector2.Zero && dir != Vector2.Zero)
				spriteRenderer.rotation = MathF.Atan2 (MovementHelper.velocity.Y, MovementHelper.velocity.X) - MathF.PI / 2;

			// checks to see if enemy bullets hit the player
			for (int i = 0; i < enemyBullets.Count; i++) {
				bool wasHit = enemyBullets[i].TryHit (box, Health);
				if (wasHit) {
					var hitPartical = enemyBullets[i].CreateHitPartical (0.5f);
					gameWorld.particals.Add (hitPartical);
				}
			}

			// gets the direction the player is aiming in
			var aimDir = input.gameWorld.camera.ScreenToWorld (Game1.MouseInWindowTex);
			aimDir -= box.position;
			aimDir.Normalize ();

			// rotates the gun sprite
			gunRenderer.rotation = MathF.Atan2 (aimDir.Y, aimDir.X) + ROT_OFFSET;

			// logic to fire the gun
			// (Check mouse button                                )  (check bullet recovery )
			if (Game1.mouseState.LeftButton == ButtonState.Pressed && recovHeavyCurrent <= 0) {
				var bullet = emitter.CreateBullet (box.position, aimDir);
				
				input.gameWorld.playerBullets.Add (bullet);
				recovHeavyCurrent = RECOV_HEAVY;

				var particalRenderer = new SpriteRenderer ();
				particalRenderer.texture = Game1.gunfire;
				particalRenderer.source = new Rectangle (new Point(0, 0), particalSize);
				//input.gameWorld.CreatePartical (box.position + emitter.Offset * aimDir, bullet.velocity * particalVelMult, particalLifeTime, particalRenderer, particalFrames) ;
				gameWorld.particals.Add (emitter.CreateGunFirePartical (box.position, aimDir, particalVelMult));
				MovementHelper.velocity *= SLOW_AMOUNT;
			}

			// calculates the speed based on bullet recovery
			/*MovementHelper.Update (SPEED * dir, dt);
			var collResult = gameWorld.MoveAndCollide (box, MovementHelper.velocity * dt);
			box.position = collResult.nPosition;*/

			SetTargetVelocity (SPEED * dir);
			PhysicsUpdate (gameWorld, movement, dt);
			//movement.WallImpact (collResult.collidedX, collResult.collidedY);
			/*float recovTime = recovHeavyCurrent / RECOV_HEAVY;
			recovTime = recovTime * recovTime;

			float overallSpeed = MathHelper.Lerp (SPEED, SLOW_SPEED, recovTime);

			// moves the player and handles collision
			var collideResult = input.gameWorld.MoveAndCollide (box, dir * overallSpeed * dt);
			box.position = collideResult.nPosition;
			*/
			if (Health.IsDead)
				input.gameWorld.QueueLevelLoad ();
		}

		public static Vector2 GetCameraOffset (Vector2 windowSize, Vector2 mousePosition, float offset) {
			Vector2 difference = mousePosition - windowSize * 0.5f;
			if (difference == Vector2.Zero) return Vector2.Zero;
			return Vector2.Normalize (difference) * offset;
		}


		// drawing logic
		public override void Draw (SpriteBatch spriteBatch) {
			spriteRenderer.Draw (box.position, spriteBatch); // draws the base of the tank
			gunRenderer.Draw (box.position, spriteBatch); // draws the gun
		}

	}
}
