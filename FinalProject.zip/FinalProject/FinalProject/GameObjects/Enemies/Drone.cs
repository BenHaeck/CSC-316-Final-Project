﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FinalProject {
	public class Drone:Entity<EnemyInput> {
		public BBox2D box = new BBox2D(Vector2.Zero, Vector2.One * 20);
		SpriteRenderer spriteRenderer = new SpriteRenderer();

		// stats
		const float SPEED = 60;
		const int DAMAGE = 15;

		// this lets things outside the class read this
		public float FacingDir => spriteRenderer.rotation;

		HealthMan healthMan = new HealthMan (3);

		public Drone () {
			
			spriteRenderer.texture = Game1.droneR;
			
		}

		public override void Update (EnemyInput input, float dt) {
			// creates and assigns the direction to the player
			Vector2 dir = Vector2.Zero;
			dir = Vector2.Normalize (input.player.box.position - box.position);

			// checks if the player and the drone collide
			if (BBox2D.Intersects (box, input.player.box)) {
				Kill ();
				input.player.Health.Damage (DAMAGE);
			}

			// gets the player bullet list
			var playerBullets = input.gameWorld.playerBullets;
			for (int i = 0; i < playerBullets.Count; i++) { // loops through and alls try hit
				if (playerBullets[i].TryHit (box, healthMan)) {
					var partical = playerBullets[i].CreateHitPartical (1);
					input.gameWorld.particals.Add (partical);
				}
			}

			// destroys the object if it runs out of health
			if (healthMan.IsDead) Kill ();


			spriteRenderer.rotation = MathF.Atan2 (dir.Y, dir.X) - MathF.PI / 2;

			box.position += dir * SPEED * dt;
		}

		public override void Draw (SpriteBatch spriteBatch) {
			spriteRenderer.Draw (box.position, spriteBatch);
		}


	}
}
