﻿using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject {
    public class EnemyTank: PhysicsCharacter<EnemyInput> {
        //public BBox2D box = new BBox2D (Vector2.Zero, Vector2.One*20);

        static Vector2 rotDeciderVector = new Vector2 (1, 0.4f) * 2;
        static Vector2 rotDeciderVector2 = new Vector2 (-0.8f, 3);

        // Renderers
        SpriteRenderer spriteRenderer = new SpriteRenderer ();
        SpriteRenderer gunRenderer = new SpriteRenderer ();

        public float facingDirection => gunRenderer.rotation;

        // Helper classes
        HealthMan healthMan;
        BulletEmitter emitter;
        Movement movement = new Movement ();
        EnemyAI ai = new EnemyAI ();

        // constents
        const float ROT_OFFSET = -MathF.PI/ 2;
        //const float BUMPSPEED = 1;

        readonly float SPEED = 10;
        readonly float BULLET_RECOV = 1.5f;
        //float SIGHT_RADIUS = 32*3;


        // the time until it can shoot again
        float bulletRecovCurrent = 0;
        

        bool agro = false;

        public EnemyTank (TankSettings tankSettings) {
            if (tankSettings == null) {
                tankSettings = new TankSettings ();
            }

            this.SPEED = tankSettings.speed;
            this.BULLET_RECOV = tankSettings.bulletRecov;


            this.spriteRenderer = (SpriteRenderer)tankSettings.spriteRenderer.Clone();
            
            this.gunRenderer = (SpriteRenderer)tankSettings.gunRenderer.Clone();

            this.emitter = (BulletEmitter)tankSettings.emitter.Clone ();
            
            
            healthMan = new HealthMan (tankSettings.health); 
            ai.AgroRange = tankSettings.sightRadius;
            movement.VelChange = 2;
            SetHelpers (new object[] { ai, movement, emitter, healthMan});
            //Debug.WriteLine ($"has ai {ai}");
            box.Size = Vector2.One * 20;
        }

        //public void SetupEnemy (float)

        public override void Update (EnemyInput input, float dt) {
            // gets things from the game world, and puts them into temporary variables to make things easier
            var player = input.player;
            var gameWorld = input.gameWorld;
            var playerBullets = gameWorld.playerBullets;
            var enemies = gameWorld.enemyTanks;

            // counts down until it can shoot again, but won't count past zero
            bulletRecovCurrent = MathF.Max (0, bulletRecovCurrent - dt);

            ai.Update (player, box.position);

            // gets the direction
            //var dir = player.box.position - box.position;
            Vector2 moveDir = Vector2.Zero; // the direction the enemy moves in
            Vector2 aimDir = Vector2.Zero; // the direction the enemy aims in
            if (ai.dirToPlayer != Vector2.Zero) {
                if (!Collide) { // checks if the enemy has collided with a wall
                    //dir.Normalize ();
                    moveDir = ai.dirToPlayer;
                    aimDir = ai.dirToPlayer;
                }
                else {
                    moveDir = new Vector2 (MathF.Sign (ai.dirToPlayer.X), MathF.Sign (ai.dirToPlayer.Y)); // helps enemies get around walls
                    if (CollideX)
                        moveDir.X *= 0.1f;
                    if (CollideY)
                        moveDir.Y *= 0.1f;
                    aimDir = ai.dirToPlayer;
                }

                // rotates the base of the tank to face the direction its moving in
                if (movement.velocity != Vector2.Zero)
                    spriteRenderer.rotation = MathF.Atan2 (movement.velocity.Y, movement.velocity.X) + ROT_OFFSET;
            }

            // checks if it can see the player
            /*if (Vector2.DistanceSquared (player.box.position, box.position) < SIGHT_RADIUS * SIGHT_RADIUS) {
                Agro ();
            }*/

            // checks whether the players bullets collide with the enemy
            for (int i = 0; i < playerBullets.Count; i++) {
                var wasHit = playerBullets[i].TryHit (box, healthMan);
                if (wasHit) {
                    ai.Agro ();

                    var hitPartical = playerBullets[i].CreateHitPartical (0.5f);
                    gameWorld.particals.Add (hitPartical);
                }
            }

            /*for (int i = 0; i < enemies.Count; i++) {
                var distanceSq = Vector2.DistanceSquared (box.position, enemies[i].box.position);

			    if (distanceSq < SIGHT_RADIUS * SIGHT_RADIUS && agro) {
					enemies[i].Agro ();
                }
                var enemyBumpDist = (box.Size.X + box.Size.Y) * 1.5f;

                if (distanceSq < enemyBumpDist && this != enemies[i]) {
                    moveDir -= Vector2.Normalize (enemies[i].box.position - box.position) * BUMPSPEED;
                }
                
			}*/

            
            if (ai.Agrod) { // checks if the enemy has agroed onto the player
                // shoots the player if it can, and if there it has line of sight of the player
                // (can shoot player       )&& (         player in line of sight                       )
                if (bulletRecovCurrent <= 0 && !gameWorld.wm.Raycast (box.position, player.box.position)) {
                    bulletRecovCurrent = BULLET_RECOV;
                    var bullet = emitter.CreateBullet (box.position, aimDir);
                    gameWorld.enemyBullets.Add (bullet);
                    gameWorld.particals.Add (emitter.CreateGunFirePartical (box.position, aimDir, 0.5f));
                }

                // updates the gun rotation
                gunRenderer.rotation = MathF.Atan2 (aimDir.Y, aimDir.X) + ROT_OFFSET;
                
                SetTargetVelocity (SPEED * moveDir);
                PhysicsUpdate (gameWorld, movement, dt);
                
            }
            else {
                // if the enemy is not agroed it will use this to find default rotations to stop every enemy from looking down when the level starts
                gunRenderer.rotation = Vector2.Dot (box.position, rotDeciderVector);
                spriteRenderer.rotation = Vector2.Dot (box.position, rotDeciderVector2);
            }

            // removes the enemy from the list if the health is zero
            if (healthMan.IsDead) Kill ();
        }

        public class TankSettings {
            public SpriteRenderer spriteRenderer = new SpriteRenderer () {texture = Game1.tankRBase},
            gunRenderer = new SpriteRenderer () { texture = Game1.tankRGun, originOffset = Vector2.UnitY * -3};
            public BulletEmitter emitter = new BulletEmitter (new Bullet (4, new SpriteRenderer () { texture = Game1.bulletTex }, 10), 120, 12);

            public float speed = 10, bulletRecov = 1.5f, sightRadius = 32*4f;
            public int health = 20;

            

		}

        // agros the enemy onto the player
        public void Agro () {
            if (!agro) {
                agro = true;
            }
        }

        public override void Draw (SpriteBatch spriteBatch) {
            spriteRenderer.Draw (box.position, spriteBatch);
            gunRenderer.Draw (box.position, spriteBatch);
        }
    }
}
