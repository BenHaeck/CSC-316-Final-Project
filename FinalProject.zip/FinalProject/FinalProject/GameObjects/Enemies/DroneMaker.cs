﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FinalProject{
	public class DroneMaker:PhysicsCharacter<EnemyInput> {

		// Helper Objects
		EnemyAI ai = new EnemyAI();
		Movement movement = new Movement();
		HealthMan healthMan = new HealthMan(40);

		static Random random = new Random ();

		public const float SPEED = 20;

		public const float RECOV = 6;
		float recovCurrent = 0;

		public const float ANIMATION_TIME = 1;

		readonly int NUM_FRAMES;

		const float SPEED_CHANGE_INTERVOL = 1.8f;
		const float HIT_PARTICLE_MULT = 0.25f;
		float timeUntilSpeedChange = 0;

		Vector2 moveDir;

		SpriteRenderer renderer = new SpriteRenderer ();

		public DroneMaker () {
			// makes the helper classes readable from outside the function
			SetHelpers (new object[] {ai, movement, healthMan});
			ai.AgroRange = 128;
			renderer.texture = Game1.droneTank;
			renderer.source = new Rectangle (0,0,32,32);

			NUM_FRAMES = renderer.texture.Width / renderer.source.Value.Width;
			movement.VelChange = 20;
			box.Size = Vector2.One * 24;
		}

		public override void Update (EnemyInput input, float dt) {
			ai.Update (input.player, box.position);
			
			//testing bullet collisions
			var playerBullets = input.gameWorld.playerBullets;
			for (int i = 0; i < playerBullets.Count; i++) {
				if (playerBullets[i].TryHit (box, healthMan)) {
					var particle = playerBullets[i].CreateHitPartical (HIT_PARTICLE_MULT);
					input.gameWorld.particals.Add (particle);
					ai.Agro ();
				}
			}

			if (healthMan.IsDead)
				Kill ();

			if (ai.Agrod) {
				timeUntilSpeedChange -= dt;
				if (timeUntilSpeedChange < 0 || Collide) { // makes the dronemaker move in a different random direction after a timer ticks doen
					// generates 2 random floats
					moveDir = new Vector2 (random.NextSingle () * 2 - 1, random.NextSingle () * 2 - 1);
					moveDir.X *= MathF.Abs(moveDir.X); // this fixes something I think
					moveDir.Y *= MathF.Abs(moveDir.Y);
					moveDir.Normalize (); // normalizes the direction
					timeUntilSpeedChange = SPEED_CHANGE_INTERVOL; // resets the timer
				}

				recovCurrent -= dt;

				// this is an overly clever way of animating it.
				// because the function clamps the value, I can enter any value and it will return a valid animation frame
				// because of this, the equation it takes as input will be equal to a negative number until it is time to animate
				renderer.animationFrameX = MathStuff.AnimateClamp (NUM_FRAMES, 1 - recovCurrent / ANIMATION_TIME);
				if (recovCurrent < 0) {
					var drone = new Drone (); // makes a new drone
					drone.box.position = box.position;
					input.gameWorld.drones.Add (drone);
					recovCurrent = RECOV;
				}

				// handles all of the physics
				SetTargetVelocity (moveDir * SPEED);
				PhysicsUpdate (input.gameWorld, movement, dt);
				movement.WallImpact (CollideX, CollideY);
			}

			// handles object rotation
			if (movement.velocity != Vector2.Zero) {
				renderer.rotation = MathF.Atan2 (movement.velocity.Y, movement.velocity.X) - MathF.PI / 2;
			}

			base.Update (input, dt);
		}

		public override void Draw (SpriteBatch spriteBatch) {
			renderer.Draw (box.position, spriteBatch);
			base.Draw (spriteBatch);
		}


	}
}
