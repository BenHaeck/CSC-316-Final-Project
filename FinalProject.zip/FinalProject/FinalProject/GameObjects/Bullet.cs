﻿using Engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace FinalProject {
	public class Bullet : Entity<EntityInput>, ICloneable{
		public BBox2D box2D = new BBox2D ();

		public Vector2 velocity = Vector2.Zero;
		SpriteRenderer spriteRenderer = new SpriteRenderer ();
		public SpriteRenderer lightRenderer = null;

		bool rotate = true;

		readonly int numFrames = 1;

		const float animSpeed = 0.1f;

		float drag = 0;
		public float Drag {
			set { drag = value; }
			get => drag;
		}

		float lifeTime = 0;

		// the damage the bullet does
		int damage = 1;
		// getter & setter
		public int Damage {
			set {
				if (value < 0)
					damage = 0;
				else
					damage = value;
			}
			get { return damage; }
		}

		public Bullet (float size, SpriteRenderer renderer, int damage = 1, float lifeTime = 10000, float drag = 0, bool rotate = true) {
			spriteRenderer = renderer;
			box2D.Size = Vector2.One * size;
			this.damage = damage;

			this.lifeTime = lifeTime;
			this.drag = drag;


			this.rotate = rotate;

			if (renderer.source.HasValue)
				numFrames = renderer.texture.Bounds.Width / renderer.source.Value.Width;
			else
				numFrames = 1;
		}

		public override void Update (EntityInput input, float dt) {
			velocity *= MathF.Exp (-drag * dt);
			box2D.position += velocity * dt; // moves the bullet

			lifeTime -= dt;
			if (lifeTime < 0)
				Kill ();

			this.spriteRenderer.animationFrameX = (int)(lifeTime / animSpeed) % numFrames;

			if (input.gameWorld.wm.Intersects (box2D)) { // checks for intersection with any walls
				Kill (); // destroys the bullet
				var partical = CreateHitPartical (-0.1f); // creates a partical
				input.gameWorld.particals.Add (partical); // adds the partical to the game world
			}
			base.Update (input, dt);

			// rotates the bullet to face the direction it's moving in
			if (rotate)
				spriteRenderer.rotation = MathF.Atan2 (velocity.Y, velocity.X) - MathF.PI / 2;
		}


		public override void Draw (SpriteBatch spriteBatch) {
			spriteRenderer.Draw (box2D.position, spriteBatch);
			base.Draw (spriteBatch);
		}

		public void DrawLight (SpriteBatch spriteBatch) {
			if (lightRenderer != null)
				lightRenderer.Draw (box2D.position, spriteBatch);
		}

		// returns a clone of the object
		public object Clone () {
			var clone = (Bullet)MemberwiseClone ();
			clone.spriteRenderer = (SpriteRenderer)spriteRenderer.Clone ();
			if (lightRenderer != null) {
				clone.lightRenderer = (SpriteRenderer)lightRenderer.Clone ();
			}
			return clone;
		}

		// creates a partical for when it hits something
		public Partical CreateHitPartical (float hitVelMult) {
			var particalRenderer = new SpriteRenderer (); // assigns the renderer
			particalRenderer.texture = Game1.bulletHit; // assigns the sprite
			particalRenderer.source = new Rectangle (0, 0, 16, 16); // assigns the source rectangle
			var partical = new Partical (0.25f, 5, particalRenderer); // creates the particle
			partical.position = box2D.position; // sets the position
			partical.velocity = velocity * hitVelMult; // sets the velocity
			return partical;
		}


		// Tries to hit an object, if it does, it will decrease said objects health
		public bool TryHit (BBox2D box, HealthMan healthMan) {
			if (BBox2D.Intersects (box2D, box)) {
				healthMan.Damage (damage); // reduces the health
				Kill (); // destroyes the bullet
				return true;
			}
			return false;
		}
	}
}
