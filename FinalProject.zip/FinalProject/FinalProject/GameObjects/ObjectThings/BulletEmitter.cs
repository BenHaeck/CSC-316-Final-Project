﻿using System;

using System.Threading.Tasks;
using Engine;
using Microsoft.Xna.Framework;

namespace FinalProject {
	public class BulletEmitter: ICloneable{
		static Random rand = new Random ();

		Bullet template;

		Vector2 spreadAndSpeed = Vector2.UnitY;

		public Bullet Template {
			set { template = value; }
			get { return template; }
		}

		public float Speed => spreadAndSpeed.Y;
		//float bulletSpeed;

		float offset;
		public float Offset => offset;

		public BulletEmitter (Bullet template, float speed, float offset) {
			this.template = template;
			this.offset = offset;
			spreadAndSpeed.Y = speed;
		}

		public BulletEmitter (Bullet template, Vector2 speed, float offset) {
			this.template = template;
			this.offset = offset;
			spreadAndSpeed = speed;
		}

		public Bullet CreateBullet (Vector2 position, Vector2 dir) {
			var bullet = (Bullet)template.Clone ();
			bullet.velocity = dir * spreadAndSpeed.Y;
			bullet.velocity += new Vector2 (dir.Y, -dir.X) * (rand.NextSingle()*2 - 1) * spreadAndSpeed.X; 
			bullet.box2D.position = position + offset * dir;
			return bullet;
		}

		public Partical CreateGunFirePartical (Vector2 position, Vector2 dir, float speedMult) {
			var particalRenderer = new SpriteRenderer ();
			particalRenderer.texture = Game1.bulletHit;
			particalRenderer.source = new Rectangle (0, 0, 16, 16);

			var partical = new Partical (0.14f, 4, particalRenderer);
			partical.position = position + offset * dir;
			partical.velocity = dir * spreadAndSpeed.Y * speedMult;
			return partical;
		}

		public object Clone () {
			return MemberwiseClone ();
		}
	}
}
