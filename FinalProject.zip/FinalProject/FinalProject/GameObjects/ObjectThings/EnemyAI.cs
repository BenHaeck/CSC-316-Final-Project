﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Engine;
using System.Diagnostics;

namespace FinalProject{
	public class EnemyAI {
		// how close the player needs to be before being spotted
		float agroRange = 0;
		public float AgroRange {
			get { return agroRange; }
			set { agroRange = value; }
		}
		// unit vector facing towards the player
		Vector2 directionToPlayer = Vector2.Zero;
		public Vector2 dirToPlayer => directionToPlayer;
		bool agrod = false; // whether the enemy is agressive
		public bool Agrod => agrod;
		
		public void Update (Player player, Vector2 position) {
			// calculates the direction toward the player
			directionToPlayer = player.box.position - position;
			if (directionToPlayer != Vector2.Zero)
				directionToPlayer.Normalize ();

			// check if the player is within the sight radius
			if (Vector2.DistanceSquared (player.box.position, position) < agroRange * agroRange) {
				Agro ();
			}
		}

		public void Agro () {
			agrod = true;
		}

		public static void DistanceChecks (GameWorld gameWorld, List<PhysicsCharacter<EnemyInput>> enemies, float bumpForce, float dt) {
			for (int i = 1; i < enemies.Count; i++) {
				for (int j = 0; j < i; j++) {
					// gets the distance
					var dist = Vector2.Distance (enemies[i].box.position, enemies[j].box.position);

					// gets the enemy ai helpers
					var ai1 = enemies[i].GetHelpers<EnemyAI> ();
					var ai2 = enemies[j].GetHelpers<EnemyAI> ();

					// checks for if the an enemy is can see one that is agrod
					if (ai1 != null && ai2 != null) {
						if (dist < MathF.Max(ai1.agroRange, ai2.agroRange) && (ai1.agrod || ai2.agrod)) {
							ai1.Agro ();
							ai2.Agro ();
						}
					}
					else {
						Debug.WriteLine ($"{i} has {ai1}, {j} has {ai2}");
					}

					// this is just a weird way to get the average between the width & height of the bounding box
					var enemyRadius = Vector2.Dot (enemies[i].box.HalfSize + enemies[j].box.HalfSize, Vector2.One*0.5f);

					// keeps the enemies from occupying the same space
					if (dist < enemyRadius) {
						// gets the direction from one enemy to the other
						Vector2 dir = enemies[j].box.position - enemies[i].box.position;
						dir.Normalize ();
						var collResult = gameWorld.MoveAndCollide (enemies[i].box, -dir * bumpForce * 0.5f * dt);
						enemies[i].box.position = collResult.nPosition;

						collResult = gameWorld.MoveAndCollide (enemies[j].box, dir * bumpForce * 0.5f*dt);
						enemies[j].box.position = collResult.nPosition;
					}
				}
			}
		}
	}
}
