﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace FinalProject {
	public class Movement {
		public Vector2 velocity;
		float velChange = 1;

		float snapValue = 5f;

		public float VelChange {
			get => velChange;
			set { velChange = value; }
		}

		public void Update (Vector2 targetVelocity, float dt) {
			velocity = (velocity - targetVelocity) * MathF.Exp (-dt * velChange) + targetVelocity;

			float snap2 = snapValue * snapValue;
			if (targetVelocity.LengthSquared () < snap2 && velocity.LengthSquared () < snap2) {
				velocity = Vector2.Zero;
			}
		}

		public void WallImpact (bool collideX, bool collideY) {
			if (collideX)
				velocity.X = 0;

			if (collideY)
				velocity.Y = 0;
		}
	}
}
