﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject {
	public class HealthMan {
		int health;
		public int Health => health;
		public int healthMax = 10;

		public HealthMan (int healthMax) {
			health = healthMax;
			this.healthMax = healthMax;
		}

		public void Damage (int damage) {
			health -= damage;
			if (health < 0)
				health = 0;
		}

		public bool IsDead => health <= 0;
	}
}
