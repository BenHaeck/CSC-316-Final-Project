﻿using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject{
	public class Partical:Entity<object>{
		public Vector2 position;
		public Vector2 velocity;
		float lifeTime; // time until the partical deletes it self
		float startingLifeTime; // the total life time
		float numberOfFrames; // the number of frames in the particles animation
		SpriteRenderer spriteRenderer;

		public Partical (float lifeTime, float numberOfFrames, SpriteRenderer spriteRenderer) {
			this.lifeTime = lifeTime;
			startingLifeTime = lifeTime;
			this.numberOfFrames = numberOfFrames;
			this.spriteRenderer = spriteRenderer;
		}

		public override void Update (object input, float dt) {
			// reduces the life time
			lifeTime -= dt;
			if (lifeTime <= 0) Kill (); // removes the particle

			// calculates the animation frame
			spriteRenderer.animationFrameX = (int)((1 - lifeTime/startingLifeTime) * numberOfFrames);
			position += velocity * dt; // moves the particle

		}

		public override void Draw (SpriteBatch spriteBatch) {
			spriteRenderer.Draw (position, spriteBatch);
		}
	}
}
