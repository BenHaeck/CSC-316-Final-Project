﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Engine;
using System.Diagnostics;

namespace FinalProject {
	public class WallMan {
		List<Wall> walls = new List<Wall> ();
		// the sectors are a hidden rectangle that walls are assigned to
		// every time a wall is created it is assigned to a sector
		// the list of sectors are a 2D array, where for any point, it will find a x & y index for that point.
		List<Wall>[,] sectors;
		float sectorSize = 64; // the width & height of each sector
		//public SpriteRenderer spriteRenderer = new SpriteRenderer ();

		public SpriteRenderer[] sprites;

		public WallMan (int numSectorsX, int numSectorsY, float sectorSize) {
			sectors = new List<Wall>[numSectorsY, numSectorsX];
			// sets every sector to an empty array
			for (int i = 0; i < sectors.GetLength(0); i++) {
				for (int j = 0; j < sectors.GetLength (1); j++) {
					sectors[i, j] = new List<Wall> ();
				}
			}
		}

		// adds a wall
		public void AddWall (BBox2D box)  {
			var wall = new Wall (box, 3);
			walls.Add (wall);
			Point currectSector = GetSectorIndex (box.position);
			sectors[currectSector.Y, currectSector.X].Add(wall);
		}

		// checks for collision and moves the box along the x axis so that it is not in the box anymore
		public CollResult CollideX (BBox2D box) {
			bool collide = false;

			// a mostly 3x3 group of sectors that suround the object (it might be smaller depending on if the sector is on the edge of the world)
			Point fromSector = GetSectorIndex (box.position - Vector2.One * sectorSize);
			Point toSector = GetSectorIndex (box.position + Vector2.One * sectorSize);

			// loops through the sectors
			for (int ix = fromSector.X; ix <= toSector.X; ix++) {
				for (int iy = fromSector.Y; iy <= toSector.Y; iy++) {
					var sector = sectors[iy, ix];
					// loops through each individual sector
					for (int i = 0; i < sector.Count; i++) { // collides
						collide = collide || box.AlignIfIntersectEdgeX (sector[i].box);
					}
				}
			}

			// returns the result
			return new CollResult (box.position, collide, false);
		}

		// checks for collision and moves the box along the y axis so that it is not in the box anymore
		public CollResult CollideY (BBox2D box) {
			bool collide = false;

			// a mostly 3x3 group of sectors that suround the object (it might be smaller depending on if the sector is on the edge of the world)
			Point fromSector = GetSectorIndex (box.position - Vector2.One * sectorSize);
			Point toSector = GetSectorIndex (box.position + Vector2.One * sectorSize);

			// loops through the sectors
			for (int ix = fromSector.X; ix <= toSector.X; ix++) {
				for (int iy = fromSector.Y; iy <= toSector.Y; iy++) {
					// loops through each individual sector
					var sector = sectors[iy, ix];
					for (int i = 0; i < sector.Count; i++) { // collides
						collide = collide || box.AlignIfIntersectEdgeY (sector[i].box);
					}
				}
			}
			return new CollResult (box.position, false, collide);
		}

		// Moves an object and lets it collide with the walls
		public CollResult MoveAndCollide (BBox2D box, Vector2 amount) {
			bool collideX = false, collideY = false;
			// moves and collides along the x axis
			/*box.position.X += amount.X;// moves
			for (int i = 0; i < walls.Count; i++) { // collides
				collideX = collideX || box.AlignIfIntersectEdgeX (walls[i].box);
			}
			// moves and collides along the y axis
			box.position.Y += amount.Y; // moves
			for (int i = 0; i < walls.Count; i++) { // collides
				collideY = collideY || box.AlignIfIntersectEdgeY (walls[i].box);
			}*/

			box.position.X += amount.X;
			var result = CollideX (box);
			collideX = result.collidedX;
			box.position = result.nPosition;

			box.position.Y += amount.Y;
			result = CollideY(box);
			collideY = result.collidedY;
			box.position = result.nPosition;
			

			// returns the position and which axis it collided along
			return new CollResult (box.position, collideX, collideY);
		}

		

		public bool Intersects (BBox2D box) {
			// a mostly 3x3 group of sectors that suround the object (it might be smaller depending on if the sector is on the edge of the world
			Point fromSector = GetSectorIndex (box.position - Vector2.One * sectorSize);
			Point toSector = GetSectorIndex (box.position + Vector2.One * sectorSize);
			
			// loops through the nearby sectors
			for (int ix = fromSector.X; ix <= toSector.X; ix++) {
				for (int iy = fromSector.Y; iy <= toSector.Y; iy++) {
					// loops through the sector
					var sector = sectors[iy, ix];
					for (int i = 0; i < sector.Count; i++) { // collides
						if (BBox2D.Intersects (box, sector[i].box))
							return true;
					}
				}
			}
			return false;
		}

		// checks if a ray passes through a wall
		public bool Raycast (Vector2 from, Vector2 to) {
			for (int i = 0; i < walls.Count; i++) {
				if (walls[i].box.RayCastHit (from, to))
					return true;
			}
			return false;
		}

		// assigns a wall with a sprite
		void AssignSprite (Wall wall) {
			BBox2D tempBox = wall.box;
			tempBox.Size *= 0.5f;

			bool collX = false, collY = false;
			int dirX = 0, dirY = 0;

			for (int i = -1; i <= 1; i += 2) {
				tempBox.position = wall.box.position + new Vector2 (i * wall.box.Size.X, 0);
				if (!Intersects (tempBox)) {
					dirX += i;
				}
				else
					collX = true;

				tempBox.position = wall.box.position + new Vector2 (0, i * wall.box.Size.Y);
				if (!Intersects (tempBox)) {
					dirY += i;
				}
				else
					collY = true;
			}

			if (collX && collY)
				wall.spriteInd = 1+dirX + (1+dirY) * 3;
			else
				wall.spriteInd = 9;
		}

		// assigns a every wall a sprite
		public void AssignSprites () {
			for (int i = 0; i < walls.Count; i++) {
				AssignSprite (walls[i]);
			}
		}

		// removes every wall from the wall manager
		public void Clear () {
			walls.Clear ();
			// int wallsInSectors = 0;
			for (int i = 0; i < sectors.GetLength (0); i++) {
				for (int j = 0; j < sectors.GetLength (1); j++) {
					// wallsInSectors += sectors[i, j].Count;
					sectors[i, j].Clear ();
				}
			}
			// Debug.WriteLine ("number of walls " + wallsInSectors); // for checking for memory leaks
		}


		// draws the walls
		public void Draw (SpriteBatch spriteBatch) {
			for (int i = 0; i < walls.Count; i++) {
				sprites[walls[i].spriteInd].Draw (walls[i].box.position, spriteBatch);
			}
		}


		// helper functions for assigning things to sectors this exists for optimization purposes
		private int KeepPointInBoundsX (int val) {
			return Math.Clamp (val, 0, sectors.GetLength (1) - 1);
		}

		private int KeepPointInBoundsY (int val) {
			return Math.Clamp (val, 0, sectors.GetLength (0) - 1);
		}

		private int GetPositionIndex (float position) {
			return (int)(position/sectorSize);
		}

		// takes a point, and gets the sector that the point resides in
		private Point GetSectorIndex (Vector2 position) {
			return new Point (
				KeepPointInBoundsX (GetPositionIndex (position.X)),
				KeepPointInBoundsY (GetPositionIndex (position.Y))
			);
		}

		class Wall {
			public BBox2D box;
			public int spriteInd;

			public Wall (BBox2D box, int spriteInd) {
				this.box = box;
				this.spriteInd = spriteInd;
			}
		}

		
		// the result of the collision checks
		public struct CollResult {
			public CollResult (Vector2 nPosition, bool collidedX, bool collidedY) {
				this.nPosition = nPosition;

				this.collidedX = collidedX;
				this.collidedY = collidedY;
				
			}
			public Vector2 nPosition;
			public bool collidedX, collidedY;
			public bool collided => collidedX || collidedY;
		}

	}
}
