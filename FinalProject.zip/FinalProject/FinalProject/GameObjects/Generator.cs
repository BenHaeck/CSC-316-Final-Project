﻿using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject {
	public class Generator: Entity<EntityInput> {
		public BBox2D box = new BBox2D (Vector2.Zero, Vector2.One * 64);

		SpriteRenderer spriteRenderer = new SpriteRenderer ();

		HealthMan healthMan = new HealthMan (30);

		public Generator () {
			spriteRenderer.texture = Game1.generatorTex;
		}

		public override void Update (EntityInput entityInput, float dt) {
			// checks if the generator was hit by one of the players bullets
			var playerBullets = entityInput.gameWorld.playerBullets;
			for (int i = 0; i < playerBullets.Count; i++) {
				var wasHit = playerBullets[i].TryHit (box, healthMan);
				if (wasHit) {
					entityInput.gameWorld.particals.Add (playerBullets[i].CreateHitPartical(0.1f));
				}
			}

			// checks if the generators health is dead
			if (healthMan.IsDead) {
				var gameWorld = entityInput.gameWorld;
				gameWorld.QueueLevelLoad (); // queues the level to load at the end of the frame

				// increments the level
				gameWorld.LevelIndex++;
				// reads the string of the next level into a blueprint
				gameWorld.SetLevelBlueprint (BPTile.ReadLevelToBlueprint(Levels.levels[gameWorld.LevelIndex], Vector2.One * 32));
			}
		}

		public override void Draw (SpriteBatch spriteBatch) {
			spriteRenderer.Draw (box.position, spriteBatch);
		}
	}
}
