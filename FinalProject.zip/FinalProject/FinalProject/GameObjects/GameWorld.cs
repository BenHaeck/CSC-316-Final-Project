﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

using Microsoft.Xna.Framework.Graphics;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;

namespace FinalProject {
	// This holds all the information and logic related to gameplay. This exists mostly to make switching between menus
	// and gameplay easier
	public class GameWorld {
		SpriteRenderer spotlight;
		SpriteRenderer arealight;

		public GameWindow window;

		public RenderTarget2D windowTex;

		int levelIndex = 0;

		public int LevelIndex {
			get => levelIndex;

			set {
				levelIndex = (value % Levels.levels.Length);
				if (levelIndex < 0) levelIndex += Levels.levels.Length;	
			}
		}
		
		public Camera camera = new Camera ();
		Vector2 worldBounds = Vector2.Zero;
		// GameObjects
		Player player;

		// wall manager contains all of the walls. This exists so that i can impliment collision optimizations later
		public WallMan wm = new WallMan (20, 28, 48);

		// bullets. Seperate lists for player and enemy bullets
		public List<Bullet> playerBullets = new List<Bullet> ();
		public List<Bullet> enemyBullets = new List<Bullet> ();

		// self explanitory
		public List<EnemyTank> enemyTanks = new List<EnemyTank> ();
		public List<DroneMaker> droneMakers = new List<DroneMaker> ();

		public List<PhysicsCharacter<EnemyInput>> allEnemies = new List<PhysicsCharacter<EnemyInput>> ();
		

		public List<Drone> drones = new List<Drone> ();

		public List<Partical> particals = new List<Partical> ();

		public List<BPTile> levelBlueprint = new List<BPTile> ();
		
		public bool loadLevelQueued = false;

		public Generator generator;

		int fps = 0;

		//Vector2 screenSize;
		public Vector2 ScreenSize {
			get => windowTex.Bounds.Size.ToVector2();
		}
		Vector2 worldScreenSize => ScreenSize / camera.zoom;

		public GameWorld () {
			camera.position = Vector2.Zero;
			camera.zoom = 2f;
		}

		// this code is bad and will change
		public void Start () {
			generator = new Generator ();

			// creates sprite renderers for lights
			// sets up the spot light
			spotlight = new SpriteRenderer ();
			spotlight.texture = Game1.lightSplotch;
			spotlight.source = new Rectangle (0, 33, 32, 32);
			spotlight.originOffset = new Vector2 (0, -16);
			spotlight.scale = new Vector2 (4, 6);

			// sets up the area light
			arealight = new SpriteRenderer ();
			arealight.texture = Game1.lightSplotch;
			arealight.source = new Rectangle (0, 0, 32, 32);

			// sets up the ambient light
			Game1.lightingSystem.ambientLight = new Color(0.15f, 0.2f, 0.3f);


			// sets up the default sprite
			wm.sprites = new SpriteRenderer[10];
			wm.sprites[9] = new SpriteRenderer ();
			wm.sprites[9].texture = Game1.tileSet;
			wm.sprites[9].source = new Rectangle (0, 32*3, 32, 32);

			
			// this sets up the autotile
			for (int i = 0; i <= 2; i+=1) {
				for (int j = 0; j <= 2; j+=1) {
					var sp = new SpriteRenderer ();
					sp.texture = Game1.tileSet;
					sp.source = new Rectangle (i * 32, j * 32, 32, 32);
					wm.sprites[i + j*3] = sp;
				}
			}
			
			// this reads the first level into the blueprint
			levelBlueprint = BPTile.ReadLevelToBlueprint (
				Levels.levels[0], Vector2.One * 32);

			LoadLevel ();
		}

		public void QueueLevelLoad () {
			loadLevelQueued = true;
		}

		void LoadLevel () {
			// clears the gameWorld
			particals.Clear ();
			playerBullets.Clear ();
			enemyBullets.Clear ();
			enemyTanks.Clear ();
			allEnemies.Clear ();
			drones.Clear ();
			droneMakers.Clear ();
			wm.Clear ();

			worldBounds = Vector2.Zero;

			// this is input to the sniper tanks
			var sniperSettings = new EnemyTank.TankSettings () {
				spriteRenderer= new SpriteRenderer () {
					texture = Game1.tankRBase
				},
				gunRenderer = new SpriteRenderer () {
					texture = Game1.tankRGun,
					originOffset = new Vector2 (0, -3)
				},
				emitter = new BulletEmitter (new Bullet (2, new SpriteRenderer () { texture = Game1.bulletTex }, 20), 200, 12),
				speed = 10,
				bulletRecov = 3,
				sightRadius = 120
			};

			var flameTankSettings = new EnemyTank.TankSettings () {
				spriteRenderer = new SpriteRenderer {
					texture = Game1.tankFireBase
				},
				gunRenderer = new SpriteRenderer () {
					texture = Game1.tankFireGun,
					originOffset = new Vector2 (0, -3)
				},
				emitter = new BulletEmitter (new Bullet(24, new SpriteRenderer () {
					texture = Game1.fireAnim,
					source = new Rectangle(0,0,32, 32)
					}, 1, 7, 1.5f),new Vector2(40, 180) * 0.9f, 7),
				speed = 35,
				bulletRecov = 0.1f,
				sightRadius = 145,
				health = 40,
			};

			flameTankSettings.emitter.Template.lightRenderer = (SpriteRenderer)arealight.Clone();
			flameTankSettings.emitter.Template.lightRenderer.scale = new Vector2(2, 2);
			flameTankSettings.emitter.Template.lightRenderer.color = new Color(0.4f, 0.2f, 0f);


			for (int i = 0; i < levelBlueprint.Count; i++) { // loops through everything in the level and adds it to the game world
				var bpTile = levelBlueprint[i];
				worldBounds = new Vector2 (MathF.Max (bpTile.position.X, worldBounds.X), MathF.Max (bpTile.position.Y, worldBounds.Y));
				switch (bpTile.item) { //
					case 'P': // player
						player = new Player ();
						player.box.position = bpTile.position;
						break;

					case '#': // walls
						wm.AddWall (new BBox2D (bpTile.position, Vector2.One * 32));
						break;

					case 'E': // enemy

						var tempEnemy = new EnemyTank (null);
						tempEnemy.box.position = bpTile.position;
						enemyTanks.Add (tempEnemy);
						allEnemies.Add (tempEnemy);
						break;

					case 'S':// sniper
						
						var sniper = new EnemyTank (sniperSettings);
						sniper.box.position = bpTile.position;
						enemyTanks.Add (sniper);
						allEnemies.Add (sniper);
						break;

					case 'F'://streetlight
						var flameTank = new EnemyTank (flameTankSettings);
						flameTank.box.position = bpTile.position;
						enemyTanks.Add (flameTank);
						allEnemies.Add (flameTank);
						break;
					case 'D':
						var droneMaker = new DroneMaker ();
						droneMaker.box.position = bpTile.position;
						droneMakers.Add (droneMaker);
						allEnemies.Add (droneMaker);

						break;

					case 'G': // generator
						generator = new Generator ();
						generator.box.position = bpTile.position;
						break;
				}
			}
			wm.AssignSprites ();
		}

		public void Update (float dt) {
			// these will be used as input values for game objects
			var eInput = new EntityInput (this);
			var enemyinput = new EnemyInput (player, this);

			// player & generator updating
			player.Update (eInput, dt);
			generator.Update (eInput, dt);
			


			// this updates all of the game objects
			EntityFuncs.UpdateAll (allEnemies, enemyinput, dt); // this updates all of the enemies
			EntityFuncs.UpdateAll (drones, enemyinput, dt);

			EnemyAI.DistanceChecks (this, allEnemies, 50, dt);\
			// removes dead objects from these lists (these are only needed because these lists don't get passed into the update class)
			EntityFuncs.RemoveDead<EnemyTank, EnemyInput> (enemyTanks);
			EntityFuncs.RemoveDead<DroneMaker, EnemyInput> (droneMakers);

			EntityFuncs.UpdateAll (playerBullets, eInput, dt);
			EntityFuncs.UpdateAll (enemyBullets, eInput, dt);

			// updates the particals
			EntityFuncs.UpdateAll<Partical, object> (particals, null, dt);

			// updates the camera transform
			camera.PullTo (Vector2.Lerp(player.box.position, camera.ScreenToWorld(Game1.MouseInWindowTex), 0.1f) - worldScreenSize * 0.5f, 6f * dt);
			camera.position = Vector2.Clamp (camera.position, Vector2.Zero, worldBounds - worldScreenSize);
			camera.UpdateTR ();

			// loads the level
			if (loadLevelQueued) {
				loadLevelQueued = false;
				LoadLevel ();
			}

			// calculates the fps
			if (dt > 0) {
				fps = (int)MathF.Round(1/dt);
			}
		}

		// move and collide
		public WallMan.CollResult MoveAndCollide (BBox2D box, Vector2 amount) {
			bool collX = false, collY = false;

			// X axis
			box.position.X += amount.X; // moves the box along the x axis
			var res = wm.CollideX (box); // checks for wall collisions
			box.position = res.nPosition; // updates the position
			collX = res.collidedX;

			// checks for generator collsion
			collX = collX || box.AlignIfIntersectEdgeX (generator.box);


			box.position.Y += amount.Y; // moves along the Y axis
			res = wm.CollideY (box); // checks for wall collsion
			box.position = res.nPosition; // updates the position
			collY = res.collidedY;

			// checks the generator
			collY = collY || box.AlignIfIntersectEdgeY (generator.box);

			// returns the new position, and whether it hits along the x or y axis
			return new WallMan.CollResult (box.position, collX, collY);


		}

		public void Draw (SpriteBatch spriteBatch, GraphicsDevice graphicsDevice) {
			// Drawing lights needs to be done first, because for what ever reason
			// changing the render target clears the screen to black
			Game1.lightingSystem.BeginDraw (spriteBatch, camera); // begin drawing lights
			// draws player headlights
			spotlight.color = new Color(0.4f, 0.4f, 0.2f); // sets the color
			spotlight.rotation = player.facingDirection; // makes the headlight face the same direction as the player
			spotlight.Draw (player.box.position, spriteBatch); // draws the light

			// draws enemy headlights
			spotlight.color = Color.Red; // sets the headlight color
			for (int i = 0; i < enemyTanks.Count; i++) {
				spotlight.rotation = enemyTanks[i].facingDirection; // sets the headlight direction
				spotlight.Draw (enemyTanks[i].box.position, spriteBatch); // draws the light
			}

			// draws the headlights of the drone
			spotlight.scale = new Vector2 (3, 3);
			spotlight.color = Color.Yellow;
			for (int i = 0; i < drones.Count; i++) {
				spotlight.rotation = drones[i].FacingDir;
				spotlight.Draw (drones[i].box.position, spriteBatch);
			}
			spotlight.scale = new Vector2 (4, 6);

			// Drone maker light
			arealight.color = new Color(0.25f, 0, 0);
			arealight.scale = new Vector2(2);
			for (int i = 0; i < droneMakers.Count; i++) {
				arealight.Draw (droneMakers[i].box.position, spriteBatch);
			}

			// draws light coming from the generator
			arealight.scale = new Vector2 (6); // sets the scale to 6
			arealight.color = new Color(0.1f, 0.1f, 1f); // sets the color to blue
			arealight.Draw (generator.box.position, spriteBatch); // draws the light

			for (int i = 0; i < enemyBullets.Count; i++) {
				enemyBullets[i].DrawLight (spriteBatch);
			}

			Game1.lightingSystem.EndDraw (spriteBatch); // stops drawing lights
			
			graphicsDevice.SetRenderTarget (windowTex); // changes the rendertarget to the window

			graphicsDevice.Clear (Color.Gray);
			

			spriteBatch.Begin (samplerState:SamplerState.PointClamp, transformMatrix: camera.TransformMatrix);
			// this draws all of the game objects
			generator.Draw (spriteBatch);
			EntityFuncs.DrawAll <Bullet, EntityInput> (playerBullets, spriteBatch);
			EntityFuncs.DrawAll <Bullet, EntityInput> ( enemyBullets, spriteBatch);
			player.Draw (spriteBatch);
			EntityFuncs.DrawAll <EnemyTank, EnemyInput> (enemyTanks, spriteBatch);
			EntityFuncs.DrawAll<DroneMaker, EnemyInput> (droneMakers, spriteBatch);
			EntityFuncs.DrawAll<Partical, object> (particals, spriteBatch);

			wm.Draw (spriteBatch); // this draws all of the walls

			EntityFuncs.DrawAll<Drone, EnemyInput> (drones, spriteBatch);
			
			spriteBatch.End ();

			// draws the light map over the screen
			Game1.lightingSystem.DrawLightMap (spriteBatch, windowTex.Bounds.Size);

			spriteBatch.Begin (samplerState:SamplerState.PointClamp);
			// hud goes here
			spriteBatch.DrawString (Game1.font, $"HEALTH {player.Health.Health}  FPS {fps}", Vector2.Zero, Color.White, 0, Vector2.Zero, 2, SpriteEffects.None, 0);
			spriteBatch.End ();
		}

		public void SetLevelBlueprint (List<BPTile> levelBP) { levelBlueprint = levelBP; }

		public void SetLevelBlueprint (string levelString) {
			levelBlueprint = BPTile.ReadLevelToBlueprint(levelString, Vector2.One * 32);
		}

		public void ReadLevelFromIndex () {
			SetLevelBlueprint (Levels.levels[levelIndex]);
		}
	}
}
