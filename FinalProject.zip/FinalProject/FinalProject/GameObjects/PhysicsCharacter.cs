﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Microsoft.Xna.Framework;


namespace FinalProject {
	public class PhysicsCharacter<TInput>:Entity<TInput> {
		public BBox2D box;

		
		

		bool wallBonk = false;

		bool collideX, collideY;
		public bool CollideX => collideX;
		public bool CollideY => collideY;
		public bool Collide => collideX || collideY;

		Vector2 targetVelocity;
		public void SetTargetVelocity (Vector2 targetVelocity) {
			this.targetVelocity = targetVelocity;
		}

		public void PhysicsUpdate (GameWorld world, Movement movement, float dt) {
			movement.Update (targetVelocity, dt);
			var result = world.MoveAndCollide (box, movement.velocity * dt);
			if (wallBonk)
				movement.WallImpact (collideX, collideY);
			
			box.position = result.nPosition;
			collideX = result.collidedX;
			collideY = result.collidedY;
		}
	}
}
