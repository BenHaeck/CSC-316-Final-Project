﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject {
	public struct EntityInput {
		public EntityInput (GameWorld gameWorld) {
			this.gameWorld = gameWorld;
		}
		public readonly GameWorld gameWorld;
	}

	public struct EnemyInput {

		public EnemyInput (Player player, GameWorld gameWorld) {
			this.gameWorld = gameWorld;
			this.player = player;
		}
		public readonly Player player;
		public readonly GameWorld gameWorld;
	}
}
