﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FinalProject {
	public class LightingSystem {
		// an off screen canvas for the light to render to
		RenderTarget2D shadowMap;
		int downSample; // this lets you make the shadow map a fraction of the size of the screen

		// this is needed to clear the screen, and to change the current render target
		GraphicsDevice graphicsDevice;

		
		// this is a multiply blend. Basically multiplies the color already on the canvas with what your drawing
		public static BlendState multiplyBlend = new BlendState () {
			//AlphaBlendFunction = BlendFunction.Add,

			ColorSourceBlend = Blend.DestinationColor,
			ColorDestinationBlend = Blend.Zero,
			ColorBlendFunction = BlendFunction.Add
		};

		// Basically the color of the bounce light, or the amount of light that lights up unlit things
		public Color ambientLight = Color.Gray;

		public LightingSystem (GraphicsDeviceManager graphicsDevice, int downSample) {
			// this creates
			shadowMap = new RenderTarget2D (graphicsDevice.GraphicsDevice,
				graphicsDevice.PreferredBackBufferWidth/downSample, graphicsDevice.PreferredBackBufferHeight/downSample);

			

			Debug.WriteLine ($"Shadow map width {shadowMap.Width} & height {shadowMap.Height}");
			this.downSample = downSample;
			this.graphicsDevice = graphicsDevice.GraphicsDevice;

			
		}

		// prepares for drawing lights
		public void BeginDraw (SpriteBatch spriteBatch, Camera camera) {
			graphicsDevice.SetRenderTarget (shadowMap);
			graphicsDevice.Clear (ambientLight); // applies ambient light
			spriteBatch.Begin (samplerState:SamplerState.LinearClamp, blendState:BlendState.Additive,
			transformMatrix:camera.TransformMatrix * Matrix.CreateScale(1f/downSample));
		}

		// ends the sprite batch and sets the render target back to default
		public void EndDraw (SpriteBatch spriteBatch) {
			spriteBatch.End (); // ends the sprite batch

			// this is redundent now because it gets set to windowTex
			//graphicsDevice.SetRenderTarget (null); // sets the render target to default (aka back to the screen)
			
		}

		// this draws the lights from the light map to the screen
		public void DrawLightMap (SpriteBatch spriteBatch, Point screenDimensions) {
			spriteBatch.Begin (blendState:multiplyBlend);
			spriteBatch.Draw (shadowMap, new Rectangle (Point.Zero, screenDimensions), Color.White);
			spriteBatch.End ();
		}
	}
}
