﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject {
	public class Menu {
		public bool in_start = true;

		string[] startMenuOptions = { "START", "LEVELS", "QUIT" };
		string[] menuOptions = { "RESUME", "LEVELS", "QUIT" };

		string[] menuScreenBasedOnIfStart => in_start ? startMenuOptions : menuOptions;

		string[] currentMenu;

		string[] levelSelect;

		int menuPos = 0;

		bool exitGame = false;
		public bool ExitGame => exitGame;

		float timeTillNextInput = 0;
		float inputDelayTime = 0.5f;

		Keys[] usedKeys = new Keys[] {Keys.A, Keys.D, Keys.Space};

		public Menu () {
			currentMenu = startMenuOptions;


			levelSelect = new string[Levels.levels.Length + 1];
			levelSelect[0] = "BACK";
			for (int i = 0; i < Levels.levels.Length; i++) {
				levelSelect[i + 1] = "LEVEL " + (i+1);
			}
		}

		
		
		public void Update (float dt) {
			timeTillNextInput -= dt;
			if (timeTillNextInput <= 0) {
				timeTillNextInput = 0;
				if (Game1.keyboardState.IsKeyDown (Keys.A)) {
					menuPos -= 1;
					timeTillNextInput = inputDelayTime;
				}
				if (Game1.keyboardState.IsKeyDown (Keys.D)) {
					menuPos += 1;
					timeTillNextInput = inputDelayTime;
				}

				if (Game1.keyboardState.IsKeyDown (Keys.Space)) {
					timeTillNextInput = inputDelayTime;
					if (currentMenu == startMenuOptions || currentMenu == menuOptions) {
						switch (startMenuOptions[menuPos]) {
							case "START":
								Game1.gameState = GameState.Game;
								SetCurrentMenu (menuOptions);
								in_start = false;
								break;

							case "LEVELS":
								SetCurrentMenu (levelSelect);
								break;

							case "QUIT":
								exitGame = true;
								break;
						}
					}
					else if (currentMenu == levelSelect) {
						if (menuPos != 0) {
							Game1.LoadLevel (menuPos - 1);
							Game1.gameState = GameState.Game;
							in_start = false;
						}
						
						SetCurrentMenu (menuScreenBasedOnIfStart);
					}
				}
			}


			bool anyKeyDown = false;
			for (int i = 0; i < usedKeys.Length; i++) {
				if (Game1.keyboardState.IsKeyDown (usedKeys[i])) {
					anyKeyDown = true;
					break;
				}
			}
			if (!anyKeyDown) {
				timeTillNextInput = 0.0f;
			}

			if (menuPos < 0) menuPos += currentMenu.Length;
			menuPos %= currentMenu.Length;
		}

		public void Draw (SpriteBatch spriteBatch, GraphicsDevice graphicsDevice) {
			graphicsDevice.SetRenderTarget (Game1.windowTex);

			spriteBatch.Begin (samplerState:SamplerState.PointClamp);
			spriteBatch.Draw (Game1.menuTexture, new Rectangle(0,0, Game1.windowTex.Width, Game1.windowTex.Height), Color.White);
			spriteBatch.DrawString (Game1.font, "EMERGENCY SHUTDOWN", Vector2.One * 32, Color.White, 0, Vector2.Zero, 4, SpriteEffects.None, 0);

			

			for (int i = 0; i < currentMenu.Length; i++) {
				spriteBatch.DrawString (Game1.font, currentMenu[i], new Vector2 (64) + Vector2.UnitX * (64*1.5f) * i,
				(i == menuPos? Color.Red: Color.White), 
				0, Vector2.Zero, 2f, SpriteEffects.None, 0);
			}

			spriteBatch.End ();
		}

		void SetCurrentMenu (string[] options) {
			currentMenu = options;
			menuPos = 0;
		}
	}
}
