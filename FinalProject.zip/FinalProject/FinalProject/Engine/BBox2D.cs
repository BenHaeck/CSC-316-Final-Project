﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine{
    // This is a boundingbox
    public struct BBox2D {
        
        public Vector2 position; // the center of the box
        // Accessors
        Vector2 halfSize; // the size (from the center to the edge)
        public Vector2 Size {
            get { return halfSize * 2; }
            set { halfSize = value * 0.5f; }
        }

        public Vector2 HalfSize => halfSize;

        // Constructors
        public BBox2D (Vector2 position, Vector2 size) {
            this.position = position;
            this.halfSize = size * 0.5f;
        }

        public static BBox2D BoxFromPoints (Vector2 point1, Vector2 point2) {
            Vector2 size = (point1 - point2);
            size.X = MathF.Abs (size.X);
			size.Y = MathF.Abs (size.Y);

            return new BBox2D ((point1 + point2) * 0.5f, size);
		}

        // if this bounding box intersects with a different bounding box,
        // this will move it along the x axis so that they don't intersect anymore
        public bool AlignIfIntersectEdgeX (BBox2D bb) {
            var overlap = GetOverlap (this, bb); // gets the overlap
            if (overlap.X > 0 && overlap.Y > 0) { // tests to see if they intersect
                position.X += overlap.X * MathF.Sign (position.X - bb.position.X); // moves it so that is doesn't intersect anymore
                return true;
            }
            return false;
        }
		// if this bounding box intersects with a different bounding box,
		// this will move it along the Y axis so that they don't intersect anymore
		public bool AlignIfIntersectEdgeY (BBox2D bb) {
            var overlap = GetOverlap (this, bb);
            if (overlap.X > 0 && overlap.Y > 0) {
                position.Y += overlap.Y * MathF.Sign (position.Y - bb.position.Y);
                return true;
            }
            return false;
        }

        // calculates the overlap of two Bounding Boxes along each axis
        // if both the x and y of the vector are positive, then it intersects
        // otherwise it does not intersect
        public static Vector2 GetOverlap (BBox2D bb1, BBox2D bb2) {
            Vector2 sizeCombinded = bb1.halfSize + bb2.halfSize; // the combined size of the 2 boxes
            Vector2 distanceVec = bb1.position - bb2.position; // the distance along each axis

            distanceVec = new Vector2 (MathF.Abs (distanceVec.X), MathF.Abs (distanceVec.Y)); // gets the absolute value of each axis
            Vector2 overlap = sizeCombinded - distanceVec; // calculates the overlap
            return overlap;
        }

        // tests to see if two objects intersect
        public static bool Intersects (BBox2D bb1, BBox2D bb2) {
            var overlap = GetOverlap (bb1, bb2); // gets the overlap
            return overlap.X > 0 && overlap.Y > 0; // checks for intersection, and returns the result
        }

        public bool RayCastHit (Vector2 from, Vector2 to) {
            // the raycast algorithm is inacurate at short and long range's, so this check fixes false negatives
            if (!Intersects (this, BoxFromPoints(from, to)))
                return false;

            // if from and to are equal, that can cause divide by zero errors with the normalize function
            // so should that occur, this will stop the function anything breaks
            if (from == to)
                return true;

            Vector2 relativePos = position - from; // the vector from the origan to the box
            Vector2 direction = Vector2.Normalize (to - from); // the direction of the ray
            Vector2 dirPerp = new Vector2 (direction.Y, -direction.X); // the direction rotated 90 degrees

            // this will be used to find how far from the center of the box the ray can be while still being a hit
            Vector2 sizeMult = new Vector2 (MathF.Abs (direction.Y), MathF.Abs (direction.X));

            float distFromRay = MathF.Abs(Vector2.Dot (relativePos, dirPerp)); // the distance between the center of the box, and the closest point of the ray

            //    (distFromRay)<(how far it can be while still being a hit)
            return distFromRay < Vector2.Dot(sizeMult, halfSize);

        }
    }

    public struct BCircle {
        public Vector2 position = Vector2.One;

        public float radius = 0;

        public BCircle () { }
        public BCircle (Vector2 position, float radius) {
            this.position = position;
            this.radius = radius;
        }

        public static float GetOverlap (BCircle circle1, BCircle circle2) {
            return circle2.radius + circle2.radius -  Vector2.Distance (circle1.position, circle2.position);
        }

        public static bool Intersects (BCircle circle1, BCircle circle2) {
            return GetOverlap (circle1, circle2) > 0;
        }

        
    }
}
