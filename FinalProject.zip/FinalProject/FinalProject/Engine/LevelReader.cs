﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Engine {
	public struct BPTile {
		public readonly Vector2 position;
		public readonly char item;

		public BPTile (Vector2 position, char item) {
			this.position = position;
			this.item = item;
		}

		public static List<BPTile> ReadLevelToBlueprint (string level, Vector2 tileSize) {
			Vector2 tilePos = Vector2.Zero;
			var list = new List<BPTile> ();

			for (int i = 0; i < level.Length; i++) {
				switch (level[i]) {
					case ' ': // this skips spaces
						tilePos.X += tileSize.X;
						break;

					case '\n': // this handles new lines
						tilePos.Y += tileSize.Y;
						tilePos.X = 0;
						break;

					default: // this adds objects to the eventual blueprint
						list.Add (new BPTile (tilePos, level[i])); ;
						tilePos.X += tileSize.X;
						break;
				} // ends switch statement
			}// ends for loop

			return list;
		} // ends function
	}


}
