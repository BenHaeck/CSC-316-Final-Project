﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Engine {
	public class MathStuff {
		public static int AnimateClamp (int length, float stage) {
			stage = MathHelper.Clamp (stage, 0, 1);
			return (int)(stage*length);
		}
		public static int AnimateRepeat (int length, float stage) {
			return (int)(stage*length) % length;
		}

		// (vector2, float) is a way to return multiple values
		public static (Vector2, float) ScaleToFit (Vector2 size1, Vector2 size2) {
			float scale = size2.X / size1.X;

			if (scale * size1.Y <= size2.Y)
				// case for stretching to fit along the X axis, with black bars along the top and bottom
				return (new Vector2 (0, size2.Y - size1.Y * scale) * 0.5f, scale);
			else { 
				// case for stretching to fit along the Y axis, with black bars along the left and right
				scale = size2.Y / size1.Y;
				return (new Vector2 (size2.X - size1.X * scale, 0) * 0.5f, scale);
			}
		}
	}
}
