﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Engine {
	public class Camera {
		// position and zoom
		public Vector2 position = Vector2.Zero;
		public float zoom = 1;

		public Matrix TransformMatrix => trMatrix;
		Matrix trMatrix; // the matrix gets saved here, so if it gets used multiple times per frame, it will not need to be calculated again each time

		public Camera () {}
		public Camera (Vector2 position) {
			this.position = position;
		}

		// makes the camera eponentially approach a position
		public void PullTo (Vector2 targetPosition, float change) {
			position = (position - targetPosition) * MathF.Exp (-change) + targetPosition;
		}

		// this calculates the transformation matrix based on the variables in the camera
		public void UpdateTR () {
			trMatrix =  Matrix.CreateTranslation (-position.X, -position.Y, 0) * Matrix.CreateScale(zoom);
		}

		// moves a point from screen space to world space
		public Vector2 ScreenToWorld (Vector2 pos) {
			return position + pos / zoom;
		}

		// moves a point from world space to screen space
		public Vector2 WorldToScreen (Vector2 pos) {
			return (pos - position) * zoom;
		}
	}
}
