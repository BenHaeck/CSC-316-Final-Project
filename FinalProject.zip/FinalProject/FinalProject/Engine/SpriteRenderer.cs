﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Engine {
	// This is used to draw textures.
	// it contains everything you need to render a texture
	public class SpriteRenderer : ICloneable {
		// variables
		public Texture2D texture; // the texture this draws
		public Rectangle? source; // it draws from
		public Vector2 offset = Vector2.Zero; // offset from where it says to draw
		public Vector2 scale = Vector2.One; // the scale of the image
		public float rotation = 0; // the rotation of the image (in radians)
		public Color color = Color.White; // the color of the image
		public bool flipX = false, flipY = false; // whether to flip the image in different directions
		public Vector2 originOffset = Vector2.Zero; // the origin defaults to the center of the sprite. This value gets added to the origin

		public int animationFrameX = 0;
		public int animationFrameY = 0;

		// this draws the image
		public void Draw (Vector2 position, SpriteBatch spriteBatch) {
			if (texture == null) return;

			// gets the sprite effects set up (this tells the spritebatch how the sprite should be flipped)
			SpriteEffects se = SpriteEffects.None;
			if (flipX)
				se = SpriteEffects.FlipHorizontally;
			if (flipY)
				se |= SpriteEffects.FlipVertically;

			// gets the size of whats being drawn
			Vector2 srcSize = new (texture.Width, texture.Height);
			if (source.HasValue) {
				srcSize = source.Value.Size.ToVector2 ();
			}

			Rectangle? rectangle = source;
			if (source.HasValue) {
				var src = source.Value;
				src.X += rectangle.Value.Size.X * animationFrameX;
				src.Y += rectangle.Value.Size.Y * animationFrameY;
				rectangle = src;
			}

			// draws the thing
			spriteBatch.Draw (texture, position + offset, rectangle, color, rotation, srcSize * 0.5f + originOffset, scale, se, 0);
		}

		public object Clone () {
			return MemberwiseClone ();
		}
	}
}
