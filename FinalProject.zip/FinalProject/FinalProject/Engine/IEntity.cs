﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Engine {
	public class Entity<TInput> {
		
		object[] helperObjects = new object[0];

		// If this returns false, then this is flaged to be removed in any list that contains it.
		bool isAlive = true;
		public bool IsAlive => isAlive;

		// this queues the entity to be removed from what ever list its in
		public void Kill () {
			isAlive = false;
		}

		// accessor that sets the helper array to what ever the user wants
		protected void SetHelpers (object[] helperObjects) {
			this.helperObjects = helperObjects;
		}

		// returns a helper object of a certain type
		public T GetHelpers<T> () where T : class{
			for (int i = 0; i < helperObjects.Length; i++) {
				if (helperObjects[i].GetType () == typeof (T)) { // checks if a helper object is of the right type
					var ret = (T)helperObjects[i]; // casts it to the right type
					// moves it to the front of the array so that helpers that are accessed often will be at the
					// front of the array, and will be found sooner into the functions call
					MoveObjectToFront(i);
					return ret; // returns the object
				}
			}
			return null; // returns null, if there is no helper of that type
		}

		// this is unused right now
		public virtual void Setup (TInput input) { }

		// for game logic
		public virtual void Update (TInput input, float dt) {

		}

		// to draw the objects
		public virtual void Draw (SpriteBatch spriteBatch) { }

		// only used for optimization purposes
		private void MoveObjectToFront (int i) {
			object temp = helperObjects[i]; // saves the helper
			while (i > 0) {
				helperObjects[i] = helperObjects[i-1]; // moves the others to the right
				i--;
			}
			helperObjects[0] = temp; // places the helper back into the array
		}
	}

	public static class EntityFuncs {
		// for each function you need input the type, and the input type for the entity
		// I don't like that, but sadly there does not seem to be a way around it

		// updates all of the game objects in the list, and removes dead objects
		public static void UpdateAll<T, TInput> (List<T> gameObjects, TInput input, float dt) where T : Entity<TInput> {
			for (int i = 0; i < gameObjects.Count; i++) {
				gameObjects[i].Update (input, dt);
			}
			RemoveDead<T, TInput>(gameObjects);
		}

		// removes dead objects
		public static void RemoveDead<T, TInput> (List<T> gameObjects) where T : Entity<TInput> {
			for (int i = gameObjects.Count-1; i >= 0; i--) {
				if (!gameObjects[i].IsAlive)
					gameObjects.RemoveAt (i);
			}
		}

		// draws every object in the list
		public static void DrawAll<T, TInput> (List<T> gameobjects, SpriteBatch spriteBatch) where T : Entity<TInput> {
			for (int i = 0; i < gameobjects.Count; i++) {
				gameobjects[i].Draw (spriteBatch);
			}
		}
	}
}
