﻿
using var game = new FinalProject.Game1 ();
game.Run ();
