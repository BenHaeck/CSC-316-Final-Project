﻿using Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace FinalProject
{
	public class Game1: Game {
		private GraphicsDeviceManager _graphics;
		private SpriteBatch _spriteBatch;

		public static GameState gameState = GameState.Menu;

		public SpriteEffect blur;

		public static Texture2D image;
		public static SpriteFont font;

		public static Texture2D tankGBase;
		public static Texture2D tankGGun;

		public static Texture2D tankRBase;
		public static Texture2D tankRGun;

		public static Texture2D tankFireBase;
		public static Texture2D tankFireGun;

		public static Texture2D droneTank;

		public static Texture2D droneR;

		public static Texture2D generatorTex;
		public static Texture2D generatorTexDestroyed;

		public static Texture2D bulletTex;
		public static Texture2D tileSet;

		public static Texture2D bulletHit;

		public static Texture2D gunfire;

		public static Texture2D lightSplotch;
		public static Texture2D menuTexture;

		public static Texture2D fireAnim;

		// short for window texture. Draw everything to this. You can do that by calling GraphicsDevice.SetRenderTarget(windowTex)
		public static RenderTarget2D windowTex;

		// these are stored in the Game1 class because they are needed to correct mouse position to be relative to the window texture.
		// This is done whenever you get the mouse position from MouseInWindowTex
		static Vector2 windowTexOffset; // the offset between the top left corner of the window, and the top left corner of where it renders to
		static float windowTexScale = 1; // the scale of the window texture

		static GameWorld gameWorld;
		public static LightingSystem lightingSystem;

		public static KeyboardState keyboardState;

		
		public static MouseState mouseState;

		bool pausePressed;
		Menu menu;

		// this is where the mouse is inside the window texture. Use this to get the mouse position
		public static Vector2 MouseInWindowTex => (mouseState.Position.ToVector2 () - windowTexOffset) / windowTexScale;

		

		public Game1 () {
			_graphics = new GraphicsDeviceManager (this);
			Content.RootDirectory = "Content";
			
			IsMouseVisible = true;
		}

		protected override void Initialize () {
			// TODO: Add your initialization logic here

			//camera.position = new Vector2(32, 0);
			lightingSystem = new LightingSystem (_graphics, 4);
			Window.AllowUserResizing = true;
			base.Initialize ();
		}

		protected override void LoadContent () {
			_spriteBatch = new SpriteBatch (GraphicsDevice);
			image = Content.Load<Texture2D> ("PlaceHolders");

			tankGBase = Content.Load<Texture2D> ("Tank(Green)FRONT");
			tankGGun = Content.Load<Texture2D> ("Tank(Green,Gun)FRONT");
			tankRBase = Content.Load<Texture2D> ("Tank(Red)FRONT");
			tankRGun = Content.Load<Texture2D> ("Tank(Red,Gun)FRONT");
			tankFireBase = Content.Load<Texture2D> ("FlameTank");
			tankFireGun = Content.Load<Texture2D> ("FlameTankGUN");

			droneR = Content.Load<Texture2D> ("Drone(Red)");

			bulletTex = Content.Load<Texture2D>("PlayerBullet");
			fireAnim = Content.Load<Texture2D> ("FireAnim");
			tileSet = Content.Load<Texture2D> ("TileMap");

			gunfire = Content.Load<Texture2D> ("Gunfire(Tank)");

			bulletHit = Content.Load<Texture2D> ("GunfireExplosion");
			lightSplotch = Content.Load<Texture2D> ("LightSplotch");

			generatorTex = Content.Load<Texture2D> ("Generator");
			generatorTexDestroyed = Content.Load<Texture2D> ("Generator(Destroyed)");

			droneTank = Content.Load<Texture2D> ("DroneTank[Sheet]");

			windowTex = new RenderTarget2D (GraphicsDevice, 800, 480);

			menuTexture = Content.Load<Texture2D> ("MainMenu");


			//Debug.WriteLine ( $"Screen: {_graphics.PreferredBackBufferWidth}, {_graphics.PreferredBackBufferHeight}");

			var fontImage = Content.Load<Texture2D> ("Font");
			var charBounds = new List<Rectangle> ();
			var croppingList = new List<Rectangle> ();
			var kerningList = new List<Vector3> ();

			charBounds.Add (new Rectangle(60, 12, 6, 6));
			croppingList.Add (new Rectangle(0, 0, 6, 6));
			kerningList.Add (Vector3.Zero);

			for (int i = 0; i < 10; i++) {
				charBounds.Add (new Rectangle (i * 6, 12, 6, 6));
			}

			for (int i = 0; i < 13; i++) {
				charBounds.Add (new Rectangle(i * 6, 0, 6, 6));
			}

			for (int i = 0; i < 13; i++) {
				charBounds.Add (new Rectangle (i * 6, 6, 6, 6));
			}

			for (int i = 0; i < charBounds.Count; i++) {
				croppingList.Add (new Rectangle (0, 0, 6, 6));
				kerningList.Add (Vector3.Zero);
			}

			font = new SpriteFont (fontImage, charBounds, croppingList,
			new List<char> () {' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
			'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'},
			7, 6, kerningList, ' '
			);

			gameWorld = new GameWorld ();
			gameWorld.window = Window;
			gameWorld.windowTex = windowTex;
			gameWorld.Start ();

			menu = new Menu ();
			
			// TODO: use this.Content to load your game content here
		}

		protected override void Update (GameTime gameTime) {
			if (GamePad.GetState (PlayerIndex.One).Buttons.Back == ButtonState.Pressed || menu.ExitGame /*|| Keyboard.GetState ().IsKeyDown (Keys.Escape)*/)
				Exit ();

			keyboardState = Keyboard.GetState ();
			mouseState = Mouse.GetState ();
			// TODO: Add your update logic here
			float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

			bool pauseIsPressed = keyboardState.IsKeyDown (Keys.Escape);

			if (!pausePressed && pauseIsPressed) {
				switch (gameState) {
					case GameState.Game:
						gameState = GameState.Menu;
						break;

					case GameState.Menu:
						if (!menu.in_start)
							gameState = GameState.Game;
						break;
				}
			}

			pausePressed = pauseIsPressed;
			
			switch (gameState) { // decides what gets called depending on game state
				case GameState.Game:
					gameWorld.Update (dt);
					break;

				case GameState.Menu:
					// put the update function of the menu in here
					menu.Update (dt);
					break;
			
			}

			//gameWorld.ScreenSize = Window.ClientBounds.Size.ToVector2();
			
			base.Update (gameTime);
		}

		protected override void Draw (GameTime gameTime) {
			GraphicsDevice.Clear (Color.CornflowerBlue);

			//GraphicsDevice.Viewport = new Viewport (10, 10, 100, 100);
			
			// TODO: Add your drawing code here

			switch (gameState) { // decides what gets drawn depending on game state
				case GameState.Game:
					// drawing code that only executes in the game state
					gameWorld.Draw (_spriteBatch, _graphics.GraphicsDevice);
					break;

				case GameState.Menu:
					//if (!menu.in_start)
					//	gameWorld.Draw (_spriteBatch, _graphics.GraphicsDevice);
					menu.Draw (_spriteBatch, GraphicsDevice);
					// drawing code that only executes in the menu state
					break;
			}
			//gameWorld.Draw (_spriteBatch, _graphics.GraphicsDevice);
			GraphicsDevice.SetRenderTarget (null);

			_spriteBatch.Begin (samplerState: SamplerState.LinearClamp);

			
			// updates the variables needed to render the window texture to the window
			(windowTexOffset, windowTexScale) = MathStuff.ScaleToFit (windowTex.Bounds.Size.ToVector2 (), Window.ClientBounds.Size.ToVector2 ());

			// draws the windowTexture to the window
			_spriteBatch.Draw (windowTex, windowTexOffset, null, Color.White, 0, Vector2.Zero, 
				windowTexScale,
				SpriteEffects.None, 0);
			_spriteBatch.End ();

			base.Draw (gameTime);
		}

		public static void LoadLevel (int levelInd) {
			gameWorld.LevelIndex = levelInd;
			gameWorld.QueueLevelLoad ();
			gameWorld.SetLevelBlueprint (Levels.levels[gameWorld.LevelIndex]);
		} 

		
	}
}

public enum GameState {
	Game, Menu
}
